# SecureShop — Local Vulnerable Web App Lab

An intentionally vulnerable e-commerce app for practicing web application
security testing **on your own machine**. Do not deploy this anywhere
public or expose it to the internet.

## Stack

- Backend: Python FastAPI + SQLite (SQLAlchemy)
- Frontend: React + Vite + Tailwind CSS
- Auth: JWT

## Setup

### 1. Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python seed_data.py              # creates secureshop.db with sample data
uvicorn main:app --reload --port 8000
```

Backend runs at http://localhost:8000 (interactive API docs at
http://localhost:8000/docs).

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at http://localhost:5173.

## Sample accounts

| Username | Password     | Role     |
|----------|--------------|----------|
| alice    | alice123     | customer |
| bob      | bobpassword  | customer |
| admin    | admin2024    | admin    |

## Scope of this lab

This app is for local, personal educational use only — testing your own
copy running on your own machine. Do not use anything you learn here
against systems you don't own or don't have explicit permission to test.

## Note

`secureshop.db` and anything under `backend/uploads/` are generated at
runtime and are not included in this download.
