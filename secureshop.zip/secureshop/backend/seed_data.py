"""Run once to populate the local SQLite DB with sample data.

Usage:
    python seed_data.py
"""
from database import Base, engine, SessionLocal
import models
from auth import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()

if db.query(models.User).count() == 0:
    users = [
        models.User(username="alice", email="alice@example.com",
                    password_hash=hash_password("alice123"),
                    full_name="Alice Johnson", address="12 Maple St, Springfield",
                    role="customer"),
        models.User(username="bob", email="bob@example.com",
                    password_hash=hash_password("bobpassword"),
                    full_name="Bob Smith", address="45 Oak Ave, Rivertown",
                    role="customer"),
        models.User(username="admin", email="admin@secureshop.local",
                    password_hash=hash_password("admin2024"),
                    full_name="Site Administrator", address="SecureShop HQ",
                    role="admin"),
    ]
    db.add_all(users)
    db.commit()

if db.query(models.Product).count() == 0:
    products = [
        models.Product(name="Wireless Headphones", description="Over-ear noise cancelling headphones with 30h battery life.",
                        price=79.99, category="electronics",
                        image_url="https://picsum.photos/seed/headphones/400/300", stock=50),
        models.Product(name="Mechanical Keyboard", description="RGB backlit mechanical keyboard with blue switches.",
                        price=59.50, category="electronics",
                        image_url="https://picsum.photos/seed/keyboard/400/300", stock=30),
        models.Product(name="Ceramic Coffee Mug", description="12oz hand-glazed ceramic mug, dishwasher safe.",
                        price=14.99, category="home",
                        image_url="https://picsum.photos/seed/mug/400/300", stock=100),
        models.Product(name="Running Shoes", description="Lightweight running shoes with breathable mesh upper.",
                        price=89.00, category="apparel",
                        image_url="https://picsum.photos/seed/shoes/400/300", stock=40),
        models.Product(name="Yoga Mat", description="Non-slip 6mm yoga mat, includes carry strap.",
                        price=24.99, category="fitness",
                        image_url="https://picsum.photos/seed/yoga/400/300", stock=60),
        models.Product(name="Desk Lamp", description="Adjustable LED desk lamp with 3 brightness levels.",
                        price=32.00, category="home",
                        image_url="https://picsum.photos/seed/lamp/400/300", stock=25),
        models.Product(name="Backpack", description="Water-resistant 25L backpack with laptop sleeve.",
                        price=45.00, category="apparel",
                        image_url="https://picsum.photos/seed/backpack/400/300", stock=35),
        models.Product(name="Bluetooth Speaker", description="Portable speaker with 12h battery and deep bass.",
                        price=39.99, category="electronics",
                        image_url="https://picsum.photos/seed/speaker/400/300", stock=45),
    ]
    db.add_all(products)
    db.commit()

if db.query(models.Review).count() == 0:
    reviews = [
        models.Review(product_id=1, user_id=1, username="alice", rating=5, comment="Amazing sound quality, very comfortable!"),
        models.Review(product_id=1, user_id=2, username="bob", rating=4, comment="Great headphones, battery could be better."),
        models.Review(product_id=2, user_id=1, username="alice", rating=5, comment="Love the tactile feel of these switches."),
        models.Review(product_id=4, user_id=2, username="bob", rating=4, comment="Comfortable for long runs."),
    ]
    db.add_all(reviews)
    db.commit()

if db.query(models.Order).count() == 0:
    order1 = models.Order(user_id=1, total=94.98, status="delivered", shipping_address="12 Maple St, Springfield")
    db.add(order1)
    db.commit()
    db.refresh(order1)
    db.add_all([
        models.OrderItem(order_id=order1.id, product_id=1, product_name="Wireless Headphones", quantity=1, price=79.99),
        models.OrderItem(order_id=order1.id, product_id=3, product_name="Ceramic Coffee Mug", quantity=1, price=14.99),
    ])
    order2 = models.Order(user_id=2, total=59.50, status="shipped", shipping_address="45 Oak Ave, Rivertown")
    db.add(order2)
    db.commit()
    db.refresh(order2)
    db.add(models.OrderItem(order_id=order2.id, product_id=2, product_name="Mechanical Keyboard", quantity=1, price=59.50))
    db.commit()

print("Seed data created.")
print("Sample accounts:")
print("  alice / alice123  (customer)")
print("  bob   / bobpassword (customer)")
print("  admin / admin2024 (admin)")

db.close()
