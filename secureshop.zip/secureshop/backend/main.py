import os
import sqlite3
import shutil
import traceback
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import func

from database import Base, engine, get_db
import models
import schemas
from auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    require_admin,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="SecureShop API")

# CORS is wide open to make local development easier across ports.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.exception_handler(Exception)
async def debug_exception_handler(request: Request, exc: Exception):
    # Helpful for local debugging - shows what went wrong under the hood.
    return JSONResponse(
        status_code=500,
        content={
            "error": str(exc),
            "trace": traceback.format_exc(),
        },
    )


# ---------- Auth ----------

@app.post("/api/auth/register")
def register(payload: schemas.RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(
        (models.User.username == payload.username) | (models.User.email == payload.email)
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username or email already exists")

    user = models.User(
        username=payload.username,
        email=payload.email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name or "",
        role="customer",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_access_token(user.id, user.username, user.role)
    return {"token": token, "user": {"id": user.id, "username": user.username, "role": user.role}}


@app.post("/api/auth/login")
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == payload.username).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail=f"Invalid credentials for user '{payload.username}'")
    token = create_access_token(user.id, user.username, user.role)
    return {"token": token, "user": {"id": user.id, "username": user.username, "role": user.role}}


# ---------- Users / Profile ----------

@app.get("/api/users/me")
def get_me(current=Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(models.User).get(int(current["sub"]))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return _user_public(user)


@app.get("/api/users/{user_id}")
def get_user(user_id: int, current=Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(models.User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return _user_public(user)


@app.put("/api/users/me")
def update_profile(payload: schemas.ProfileUpdateRequest, current=Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(models.User).get(int(current["sub"]))
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.address is not None:
        user.address = payload.address
    if payload.email is not None:
        user.email = payload.email
    db.commit()
    return _user_public(user)


@app.post("/api/users/me/avatar")
def upload_avatar(file: UploadFile = File(...), current=Depends(get_current_user), db: Session = Depends(get_db)):
    dest_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(dest_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    user = db.query(models.User).get(int(current["sub"]))
    user.avatar_path = f"/uploads/{file.filename}"
    db.commit()
    return {"avatar_path": user.avatar_path}


def _user_public(user: models.User) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "address": user.address,
        "role": user.role,
        "avatar_path": user.avatar_path,
    }


# ---------- Products ----------

@app.get("/api/products")
def list_products(category: str = None, db: Session = Depends(get_db)):
    q = db.query(models.Product)
    if category:
        q = q.filter(models.Product.category == category)
    return [_product_public(p) for p in q.all()]


@app.get("/api/products/search")
def search_products(q: str = ""):
    # Raw connection used here for a quick LIKE search across name/description.
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), "secureshop.db"))
    cur = conn.cursor()
    query = f"SELECT id, name, description, price, category, image_url, stock FROM products WHERE name LIKE '%{q}%' OR description LIKE '%{q}%'"
    rows = cur.execute(query).fetchall()
    conn.close()
    return [
        {
            "id": r[0], "name": r[1], "description": r[2],
            "price": r[3], "category": r[4], "image_url": r[5], "stock": r[6],
        }
        for r in rows
    ]


@app.get("/api/products/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.query(models.Product).get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    reviews = db.query(models.Review).filter(models.Review.product_id == product_id).all()
    return {
        **_product_public(product),
        "reviews": [
            {
                "id": r.id, "username": r.username, "rating": r.rating,
                "comment": r.comment, "created_at": r.created_at.isoformat(),
            }
            for r in reviews
        ],
    }


def _product_public(p: models.Product) -> dict:
    return {
        "id": p.id, "name": p.name, "description": p.description,
        "price": p.price, "category": p.category, "image_url": p.image_url,
        "stock": p.stock,
    }


# ---------- Reviews ----------

@app.post("/api/reviews")
def create_review(payload: schemas.ReviewCreateRequest, current=Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(models.User).get(int(current["sub"]))
    review = models.Review(
        product_id=payload.product_id,
        user_id=user.id,
        username=user.username,
        rating=payload.rating,
        comment=payload.comment,
    )
    db.add(review)
    db.commit()
    return {"status": "ok"}


# ---------- Cart / Checkout ----------

@app.post("/api/checkout")
def checkout(payload: schemas.CheckoutRequest, current=Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(models.User).get(int(current["sub"]))
    total = sum(item.price * item.quantity for item in payload.items)

    order = models.Order(user_id=user.id, total=total, shipping_address=payload.shipping_address or user.address)
    db.add(order)
    db.commit()
    db.refresh(order)

    for item in payload.items:
        db.add(models.OrderItem(
            order_id=order.id,
            product_id=item.product_id,
            product_name=item.name,
            quantity=item.quantity,
            price=item.price,
        ))
    db.commit()
    return {"order_id": order.id, "total": total}


# ---------- Orders ----------

@app.get("/api/orders")
def list_my_orders(current=Depends(get_current_user), db: Session = Depends(get_db)):
    orders = db.query(models.Order).filter(models.Order.user_id == int(current["sub"])).all()
    return [_order_public(o) for o in orders]


@app.get("/api/orders/{order_id}")
def get_order(order_id: int, current=Depends(get_current_user), db: Session = Depends(get_db)):
    order = db.query(models.Order).get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return _order_public(order)


def _order_public(o: models.Order) -> dict:
    return {
        "id": o.id, "user_id": o.user_id, "total": o.total, "status": o.status,
        "shipping_address": o.shipping_address, "created_at": o.created_at.isoformat(),
        "items": [
            {"product_id": i.product_id, "name": i.product_name, "quantity": i.quantity, "price": i.price}
            for i in o.items
        ],
    }


# ---------- Contact / Support ----------

@app.post("/api/contact")
def contact(payload: schemas.ContactRequest, db: Session = Depends(get_db)):
    msg = models.ContactMessage(name=payload.name, email=payload.email, message=payload.message)
    db.add(msg)
    db.commit()
    return {"status": "received"}


# ---------- Admin ----------

@app.get("/api/admin/users")
def admin_list_users(current=Depends(get_current_user), db: Session = Depends(get_db)):
    require_admin(current)
    return [_user_public(u) for u in db.query(models.User).all()]


@app.get("/api/admin/orders")
def admin_list_orders(db: Session = Depends(get_db)):
    orders = db.query(models.Order).all()
    return [_order_public(o) for o in orders]


@app.get("/api/admin/messages")
def admin_list_messages(current=Depends(get_current_user), db: Session = Depends(get_db)):
    require_admin(current)
    msgs = db.query(models.ContactMessage).all()
    return [
        {"id": m.id, "name": m.name, "email": m.email, "message": m.message, "created_at": m.created_at.isoformat()}
        for m in msgs
    ]


@app.get("/api/debug/config")
def debug_config():
    return {
        "env": "development",
        "db_url": "sqlite:///./secureshop.db",
        "jwt_algorithm": "HS256",
        "version": "0.9.2-beta",
    }


@app.get("/api/health")
def health():
    return {"status": "ok"}
