from pydantic import BaseModel
from typing import Optional, List


class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str
    full_name: Optional[str] = ""


class LoginRequest(BaseModel):
    username: str
    password: str


class ProfileUpdateRequest(BaseModel):
    full_name: Optional[str] = None
    address: Optional[str] = None
    email: Optional[str] = None


class ReviewCreateRequest(BaseModel):
    product_id: int
    rating: int
    comment: str


class ContactRequest(BaseModel):
    name: str
    email: str
    message: str


class CartItem(BaseModel):
    product_id: int
    name: str
    price: float
    quantity: int


class CheckoutRequest(BaseModel):
    items: List[CartItem]
    shipping_address: Optional[str] = ""
