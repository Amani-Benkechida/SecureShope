import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Admin() {
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [orders, setOrders] = useState([]);
  const [tab, setTab] = useState("users");

  useEffect(() => {
    apiFetch("/admin/users").then(setUsers).catch(() => {});
    apiFetch("/admin/messages").then(setMessages).catch(() => {});
    apiFetch("/admin/orders").then(setOrders).catch(() => {});
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Admin dashboard</h1>
      <div className="flex gap-2 mb-6">
        {["users", "messages", "orders"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-md text-sm font-medium capitalize ${
              tab === t ? "bg-brand-600 text-white" : "bg-white border border-slate-200 text-slate-600"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "users" && (
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-left">
              <tr>
                <th className="px-4 py-2">ID</th>
                <th className="px-4 py-2">Username</th>
                <th className="px-4 py-2">Email</th>
                <th className="px-4 py-2">Role</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-slate-100">
                  <td className="px-4 py-2">{u.id}</td>
                  <td className="px-4 py-2">{u.username}</td>
                  <td className="px-4 py-2">{u.email}</td>
                  <td className="px-4 py-2 capitalize">{u.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "messages" && (
        <div className="space-y-3">
          {messages.map((m) => (
            <div key={m.id} className="bg-white border border-slate-200 rounded-lg p-4">
              <p className="font-semibold text-slate-800">{m.name} <span className="text-slate-400 font-normal">({m.email})</span></p>
              <p className="text-slate-600 text-sm mt-1">{m.message}</p>
            </div>
          ))}
        </div>
      )}

      {tab === "orders" && (
        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex justify-between">
                <span className="font-semibold text-slate-800">Order #{o.id} (user {o.user_id})</span>
                <span className="text-sm text-slate-500">${o.total.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
