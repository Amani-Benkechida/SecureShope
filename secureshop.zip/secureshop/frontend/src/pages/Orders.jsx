import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [lookupId, setLookupId] = useState("");
  const [lookupResult, setLookupResult] = useState(null);
  const [lookupError, setLookupError] = useState("");

  useEffect(() => {
    apiFetch("/orders").then(setOrders);
  }, []);

  async function handleLookup(e) {
    e.preventDefault();
    setLookupError("");
    setLookupResult(null);
    try {
      const data = await apiFetch(`/orders/${lookupId}`);
      setLookupResult(data);
    } catch (err) {
      setLookupError(err.message);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Your orders</h1>
      <div className="space-y-4 mb-10">
        {orders.length === 0 && <p className="text-slate-500">You have no orders yet.</p>}
        {orders.map((o) => (
          <div key={o.id} className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-slate-800">Order #{o.id}</span>
              <span className="text-sm text-slate-500 capitalize">{o.status}</span>
            </div>
            <p className="text-sm text-slate-500 mt-1">{new Date(o.created_at).toLocaleString()}</p>
            <div className="mt-2 text-sm text-slate-600">
              {o.items.map((it, idx) => (
                <div key={idx} className="flex justify-between">
                  <span>{it.name} x {it.quantity}</span>
                  <span>${(it.price * it.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="text-right font-bold text-slate-800 mt-2">${o.total.toFixed(2)}</div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <h2 className="font-semibold text-slate-800 mb-3">Look up an order by ID</h2>
        <form onSubmit={handleLookup} className="flex gap-2">
          <input
            value={lookupId}
            onChange={(e) => setLookupId(e.target.value)}
            placeholder="Order ID"
            className="border border-slate-300 rounded-md px-3 py-2 flex-1"
          />
          <button className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-md font-medium">
            Look up
          </button>
        </form>
        {lookupError && <p className="text-red-600 text-sm mt-3">{lookupError}</p>}
        {lookupResult && (
          <pre className="text-xs bg-slate-50 border border-slate-200 rounded-md p-3 mt-3 overflow-auto">
            {JSON.stringify(lookupResult, null, 2)}
          </pre>
        )}
      </div>
    </div>
  );
}
