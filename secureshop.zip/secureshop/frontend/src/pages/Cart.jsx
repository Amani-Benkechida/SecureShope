import { Link, useNavigate } from "react-router-dom";
import { getUser } from "../api";

export default function Cart({ cart, updateQty, removeItem }) {
  const navigate = useNavigate();
  const user = getUser();
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Your cart</h1>
      {cart.length === 0 ? (
        <p className="text-slate-500">Your cart is empty. <Link to="/" className="text-brand-600">Browse products</Link></p>
      ) : (
        <>
          <div className="space-y-3">
            {cart.map((item) => (
              <div key={item.id} className="bg-white border border-slate-200 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-slate-800">{item.name}</p>
                  <p className="text-sm text-slate-500">${item.price.toFixed(2)} each</p>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min={1}
                    value={item.quantity}
                    onChange={(e) => updateQty(item.id, Number(e.target.value))}
                    className="w-16 border border-slate-300 rounded-md px-2 py-1 text-center"
                  />
                  <span className="w-20 text-right font-medium text-slate-800">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                  <button onClick={() => removeItem(item.id)} className="text-red-500 text-sm hover:underline">
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-between items-center">
            <span className="text-lg font-bold text-slate-800">Total: ${total.toFixed(2)}</span>
            <button
              onClick={() => (user ? navigate("/checkout") : navigate("/login"))}
              className="bg-brand-600 hover:bg-brand-700 text-white px-6 py-2.5 rounded-md font-medium"
            >
              Proceed to checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
}
