import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { apiFetch } from "../api";

export default function Products({ addToCart }) {
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    setLoading(true);
    const data = await apiFetch("/products");
    setProducts(data);
    setLoading(false);
  }

  async function handleSearch(e) {
    e.preventDefault();
    setLoading(true);
    if (!query.trim()) {
      await loadAll();
      return;
    }
    const data = await apiFetch(`/products/search?q=${encodeURIComponent(query)}`);
    setProducts(data);
    setLoading(false);
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">Shop our catalog</h1>
        <p className="text-slate-500 mt-1">Quality products, honest prices.</p>
      </div>
      <form onSubmit={handleSearch} className="mb-8 flex gap-2 max-w-lg">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products..."
          className="flex-1 border border-slate-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <button className="bg-brand-600 hover:bg-brand-700 text-white px-5 py-2 rounded-md font-medium">
          Search
        </button>
      </form>

      {loading ? (
        <p className="text-slate-500">Loading products...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p) => (
            <div key={p.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
              <img src={p.image_url} alt={p.name} className="h-40 w-full object-cover" />
              <div className="p-4 flex flex-col flex-1">
                <Link to={`/products/${p.id}`} className="font-semibold text-slate-800 hover:text-brand-600">
                  {p.name}
                </Link>
                <p className="text-slate-500 text-sm mt-1 flex-1 line-clamp-2">{p.description}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="font-bold text-slate-800">${p.price.toFixed(2)}</span>
                  <button
                    onClick={() => addToCart(p)}
                    className="text-sm bg-brand-50 hover:bg-brand-100 text-brand-700 px-3 py-1.5 rounded-md font-medium"
                  >
                    Add to cart
                  </button>
                </div>
              </div>
            </div>
          ))}
          {products.length === 0 && <p className="text-slate-500">No products found.</p>}
        </div>
      )}
    </div>
  );
}
