import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { apiFetch, getUser } from "../api";

export default function ProductDetail({ addToCart }) {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [posting, setPosting] = useState(false);
  const user = getUser();

  useEffect(() => {
    load();
  }, [id]);

  async function load() {
    const data = await apiFetch(`/products/${id}`);
    setProduct(data);
  }

  async function submitReview(e) {
    e.preventDefault();
    setPosting(true);
    try {
      await apiFetch("/reviews", {
        method: "POST",
        body: JSON.stringify({ product_id: Number(id), rating: Number(rating), comment }),
      });
      setComment("");
      await load();
    } finally {
      setPosting(false);
    }
  }

  if (!product) return <div className="max-w-4xl mx-auto px-4 py-8">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <img src={product.image_url} alt={product.name} className="rounded-xl w-full h-72 object-cover" />
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{product.name}</h1>
          <p className="text-slate-500 mt-2">{product.description}</p>
          <p className="text-2xl font-bold text-slate-800 mt-4">${product.price.toFixed(2)}</p>
          <button
            onClick={() => addToCart(product)}
            className="mt-4 bg-brand-600 hover:bg-brand-700 text-white px-5 py-2 rounded-md font-medium"
          >
            Add to cart
          </button>
        </div>
      </div>

      <div className="mt-10">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Customer reviews</h2>
        <div className="space-y-4 mb-8">
          {product.reviews.length === 0 && <p className="text-slate-500 text-sm">No reviews yet.</p>}
          {product.reviews.map((r) => (
            <div key={r.id} className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">{r.username}</span>
                <span className="text-yellow-500 text-sm">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</span>
              </div>
              <div
                className="text-slate-600 text-sm mt-1"
                dangerouslySetInnerHTML={{ __html: r.comment }}
              />
            </div>
          ))}
        </div>

        {user ? (
          <form onSubmit={submitReview} className="bg-white border border-slate-200 rounded-lg p-4 max-w-lg">
            <h3 className="font-semibold text-slate-800 mb-2">Write a review</h3>
            <label className="block text-sm text-slate-600 mb-1">Rating</label>
            <select value={rating} onChange={(e) => setRating(e.target.value)} className="border border-slate-300 rounded-md px-2 py-1 mb-3">
              {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} stars</option>)}
            </select>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Share your thoughts about this product..."
              className="w-full border border-slate-300 rounded-md px-3 py-2 mb-3"
              rows={3}
            />
            <button disabled={posting} className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-md font-medium text-sm">
              {posting ? "Posting..." : "Submit review"}
            </button>
          </form>
        ) : (
          <p className="text-sm text-slate-500">Log in to leave a review.</p>
        )}
      </div>
    </div>
  );
}
