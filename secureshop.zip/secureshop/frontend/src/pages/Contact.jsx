import { useState } from "react";
import { apiFetch } from "../api";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setSending(true);
    try {
      await apiFetch("/contact", { method: "POST", body: JSON.stringify(form) });
      setSent(true);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Contact support</h1>
      <p className="text-slate-500 mb-6 text-sm">We usually respond within 24 hours.</p>
      {sent ? (
        <div className="bg-green-50 text-green-700 rounded-md px-4 py-3">
          Thanks! Your message has been sent to our support team.
        </div>
      ) : (
        <form onSubmit={submit} className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full border border-slate-300 rounded-md px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full border border-slate-300 rounded-md px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              rows={4}
              className="w-full border border-slate-300 rounded-md px-3 py-2"
            />
          </div>
          <button disabled={sending} className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-md font-medium text-sm">
            {sending ? "Sending..." : "Send message"}
          </button>
        </form>
      )}
    </div>
  );
}
