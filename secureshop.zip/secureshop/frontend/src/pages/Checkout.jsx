import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch, getUser } from "../api";

export default function Checkout({ cart, clearCart }) {
  const [address, setAddress] = useState(getUser()?.address || "");
  const [placing, setPlacing] = useState(false);
  const [orderId, setOrderId] = useState(null);
  const navigate = useNavigate();
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  async function placeOrder() {
    setPlacing(true);
    try {
      const payload = {
        items: cart.map((item) => ({
          product_id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
        })),
        shipping_address: address,
      };
      const result = await apiFetch("/checkout", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setOrderId(result.order_id);
      clearCart();
    } finally {
      setPlacing(false);
    }
  }

  if (orderId) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-slate-800 mb-2">Order placed!</h1>
        <p className="text-slate-500 mb-6">Your order #{orderId} has been received.</p>
        <button onClick={() => navigate("/orders")} className="bg-brand-600 hover:bg-brand-700 text-white px-5 py-2 rounded-md font-medium">
          View my orders
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Checkout</h1>
      <div className="bg-white border border-slate-200 rounded-lg p-5 mb-6">
        <label className="block text-sm font-medium text-slate-700 mb-1">Shipping address</label>
        <textarea
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          rows={3}
          className="w-full border border-slate-300 rounded-md px-3 py-2"
        />
      </div>
      <div className="bg-white border border-slate-200 rounded-lg p-5 mb-6">
        {cart.map((item) => (
          <div key={item.id} className="flex justify-between text-sm text-slate-600 py-1">
            <span>{item.name} x {item.quantity}</span>
            <span>${(item.price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
        <div className="flex justify-between font-bold text-slate-800 mt-3 pt-3 border-t border-slate-200">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>
      </div>
      <button
        onClick={placeOrder}
        disabled={placing || cart.length === 0}
        className="w-full bg-brand-600 hover:bg-brand-700 text-white py-2.5 rounded-md font-medium"
      >
        {placing ? "Placing order..." : "Place order"}
      </button>
    </div>
  );
}
