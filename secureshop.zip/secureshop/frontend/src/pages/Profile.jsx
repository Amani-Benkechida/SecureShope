import { useEffect, useState } from "react";
import { apiFetch, apiUpload, API_BASE } from "../api";

export default function Profile() {
  const [profile, setProfile] = useState(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    apiFetch("/users/me").then(setProfile);
  }, []);

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      const updated = await apiFetch("/users/me", {
        method: "PUT",
        body: JSON.stringify({
          full_name: profile.full_name,
          address: profile.address,
          email: profile.email,
        }),
      });
      setProfile(updated);
      setMessage("Profile updated.");
    } finally {
      setSaving(false);
    }
  }

  async function uploadAvatar(e) {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const result = await apiUpload("/users/me/avatar", formData);
      setProfile((p) => ({ ...p, avatar_path: result.avatar_path }));
      setMessage("Avatar uploaded.");
    } finally {
      setUploading(false);
    }
  }

  if (!profile) return <div className="max-w-lg mx-auto px-4 py-8">Loading...</div>;

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Your profile</h1>
      {message && <div className="bg-green-50 text-green-700 text-sm rounded-md px-3 py-2 mb-4">{message}</div>}

      <div className="bg-white border border-slate-200 rounded-lg p-5 mb-6">
        <div className="flex items-center gap-4 mb-4">
          {profile.avatar_path ? (
            <img src={`http://localhost:8000${profile.avatar_path}`} alt="avatar" className="w-16 h-16 rounded-full object-cover border" />
          ) : (
            <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 text-xl">
              {profile.username?.[0]?.toUpperCase()}
            </div>
          )}
          <div>
            <p className="font-semibold text-slate-800">{profile.username}</p>
            <p className="text-sm text-slate-500 capitalize">{profile.role}</p>
          </div>
        </div>
        <form onSubmit={uploadAvatar} className="flex items-center gap-2">
          <input type="file" onChange={(e) => setFile(e.target.files[0])} className="text-sm" />
          <button disabled={uploading} className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-md text-sm font-medium">
            {uploading ? "Uploading..." : "Upload avatar"}
          </button>
        </form>
      </div>

      <form onSubmit={save} className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Full name</label>
          <input
            value={profile.full_name || ""}
            onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
            className="w-full border border-slate-300 rounded-md px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
          <input
            value={profile.email || ""}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
            className="w-full border border-slate-300 rounded-md px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
          <textarea
            value={profile.address || ""}
            onChange={(e) => setProfile({ ...profile, address: e.target.value })}
            rows={2}
            className="w-full border border-slate-300 rounded-md px-3 py-2"
          />
        </div>
        <button disabled={saving} className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-md font-medium text-sm">
          {saving ? "Saving..." : "Save changes"}
        </button>
      </form>
    </div>
  );
}
