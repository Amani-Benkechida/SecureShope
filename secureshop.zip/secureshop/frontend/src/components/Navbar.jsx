import { Link, useNavigate } from "react-router-dom";
import { getUser, clearSession } from "../api";

export default function Navbar({ cartCount }) {
  const navigate = useNavigate();
  const user = getUser();

  function logout() {
    clearSession();
    navigate("/login");
  }

  return (
    <nav className="bg-brand-700 text-white shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-xl font-bold tracking-tight">
          Secure<span className="text-brand-100">Shop</span>
        </Link>
        <div className="flex items-center gap-5 text-sm font-medium">
          <Link to="/" className="hover:text-brand-100">Products</Link>
          {user && <Link to="/orders" className="hover:text-brand-100">Orders</Link>}
          {user && <Link to="/profile" className="hover:text-brand-100">Profile</Link>}
          {user?.role === "admin" && (
            <Link to="/admin" className="hover:text-brand-100">Admin</Link>
          )}
          <Link to="/contact" className="hover:text-brand-100">Contact</Link>
          <Link to="/cart" className="relative hover:text-brand-100">
            Cart
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-4 bg-yellow-400 text-brand-900 text-xs rounded-full px-1.5 py-0.5">
                {cartCount}
              </span>
            )}
          </Link>
          {user ? (
            <button onClick={logout} className="bg-brand-500 hover:bg-brand-600 px-3 py-1.5 rounded-md">
              Logout ({user.username})
            </button>
          ) : (
            <>
              <Link to="/login" className="hover:text-brand-100">Login</Link>
              <Link to="/register" className="bg-brand-500 hover:bg-brand-600 px-3 py-1.5 rounded-md">
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
